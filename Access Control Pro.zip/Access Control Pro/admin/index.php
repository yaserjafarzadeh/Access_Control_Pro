<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit('Direct access not allowed.');
}
