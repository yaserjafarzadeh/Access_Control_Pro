<?php
/**
 * Security file to prevent direct access
 * Advanced Access Control Pro
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit('Direct access not allowed.');
}
